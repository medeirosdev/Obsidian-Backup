# text-recognize
Reconhecimento de textos em imagens
