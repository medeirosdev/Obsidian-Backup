# keras-tensorflow

Repo para os arquivos do primeiro curso de Keras na Alura
