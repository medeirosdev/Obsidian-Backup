# ML_Classificacao_por_tras_dos_panos

* Curso Alura: Machine Learning: Classificação por trás dos panos

* Objetivo: introduzir os primeiros e principais conceitos de Machine Learning, para você entrar de vez nesse mundo dos dados.

* Projeto: Classificação de um dataset de clientes da empresa de telecomunicações Alura Voz.

